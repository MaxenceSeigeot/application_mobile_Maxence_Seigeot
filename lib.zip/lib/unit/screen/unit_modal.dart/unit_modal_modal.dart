import 'package:emergence/unit/screen/unit_modal.dart/widgets/unit_modal_field.dart';
import 'package:emergence/unit/screen/unit_modal.dart/widgets/unit_modal_header.dart';
import 'package:emergence/unit/screen/unit_modal.dart/widgets/unit_modal_validation.dart';
import 'package:flutter/material.dart';
import 'package:emergence/unit/service/unit_service.dart';
import 'package:emergence/models/unit_model.dart';

class UnitModal extends StatefulWidget {
  final Unit unit;

  const UnitModal({Key? key, required this.unit}) : super(key: key);

  @override
  _UnitModalState createState() => _UnitModalState();
}

class _UnitModalState extends State<UnitModal> {
  late UnitService unitService;
  late Map<String, TextEditingController> _controllers;

  @override
  void initState() {
    super.initState();
    unitService = UnitService(context);
    _controllers = {};
    widget.unit.toMap().forEach((key, value) {
      _controllers[key] = TextEditingController(text: value.toString());
      // Add listener to apt, wounded, and dead fields
      if (key == 'apt' || key == 'wounded' || key == 'dead') {
        _controllers[key]!.addListener(() {
          // Update the size field when apt, wounded, or dead changes
          final int apt = int.tryParse(_controllers['apt']!.text) ?? 0;
          final int wounded = int.tryParse(_controllers['wounded']!.text) ?? 0;
          final int dead = int.tryParse(_controllers['dead']!.text) ?? 0;
          final int size = apt + wounded + dead;
          _controllers['size']!.text = size.toString();
        });
      }
    });
  }

  @override
  void dispose() {
    _controllers.values.forEach((controller) => controller.dispose());
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Material(
        color: Colors.transparent,
        child: AlertDialog(
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                UnitModalHeader(controllers: _controllers),
                UnitModalFields(controllers: _controllers, unit: widget.unit),
                UnitModalValidationButton(
                    validateAndSaveUnit: _validateAndSaveUnit),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _validateAndSaveUnit() {
    final Map<String, dynamic> allData = {};
    _controllers.forEach((key, controller) {
      allData[key] = controller.text;
    });

    // Dynamically parse integer fields
    final Map<String, int> intFields = {};
    final List<String> intFieldNames = [
      'size',
      'apt',
      'wounded',
      'dead',
      'strMnvr',
      'tactMnvr',
      'meleeAtk',
      'rangeAtk',
      'spAtk',
      'machineAtk',
      'deploy',
      'craft',
      'disc',
      'moral',
      'armor',
      'ap',
      'deadRatio',
    ];

    intFieldNames.forEach((fieldName) {
      final value = allData[fieldName];
      if (value != null && value.isNotEmpty) {
        intFields[fieldName] = int.tryParse(value) ?? 0;
      }
    });

    // Calculate size
    final int size =
        intFields['apt']! + intFields['wounded']! + intFields['dead']!;
    intFields['size'] = size;

    // Assign integer fields back to allData
    intFields.forEach((fieldName, value) {
      allData[fieldName] = value;
    });

    try {
      // Create or update Unit instance
      final Unit unit = Unit.fromMap(allData);

      if (widget.unit.id.isEmpty) {
        print('create');
        unitService.createUnit(unit);
      } else {
        print('update');
        unitService.updateUnit(unit.id, unit);
      }
      Navigator.pop(context);
    } catch (e) {
      // Handle any errors during Unit creation or update
      print('Error saving unit: $e');
      // Optionally, provide feedback to the user about the error
    }
  }
}
