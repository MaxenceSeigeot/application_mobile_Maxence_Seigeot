import 'package:flutter/material.dart';
import 'package:emergence/models/unit_model.dart';

class UnitModalFields extends StatelessWidget {
  final Map<String, TextEditingController> controllers;
  final Unit unit;

  const UnitModalFields(
      {Key? key, required this.controllers, required this.unit})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          // Implement the fields as before using _buildTextField and _buildReadOnlyField methods
          // ...
        ],
      ),
    );
  }
}
