import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:emergence/models/unit_model.dart';

Future<void> createUnit_(
  String gameId,
  String userId,
  Unit unit,
) async {
  print(unit);
  try {
    await FirebaseFirestore.instance
        .collection('Games')
        .doc(gameId)
        .collection('PlayersData')
        .doc(userId)
        .collection('Units')
        .add(unit.toMap());
  } catch (e) {
    rethrow;
  }
}
