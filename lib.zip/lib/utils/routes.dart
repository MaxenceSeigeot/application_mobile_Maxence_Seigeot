import 'package:emergence/group/screen/groups_screen.dart';
import 'package:flutter/material.dart';
import 'package:emergence/game/screen/components/create_game_screen.dart';
import 'package:emergence/users/auth_screen.dart';
import 'package:emergence/game/screen/games.dart';
import 'package:emergence/users/components/login_screen.dart';
import 'package:emergence/users/components/sign_up_screen.dart';

class Routes {
  static final Map<String, WidgetBuilder> routes = {
    '/login': (context) => LoginScreen(),
    '/signup': (context) => SignUpScreen(),
    '/games': (context) => const GamesScreen(),
    '/units': (context) => const GroupsScreen(),
    '/add_game': (context) => CreateGameScreen(),
    '/auth': (context) => const AuthScreen(),
  };
}
