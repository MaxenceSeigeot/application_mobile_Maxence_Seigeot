import 'package:cloud_firestore/cloud_firestore.dart';

class UsersController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<dynamic>> fetchUsers() async {
    try {
      final QuerySnapshot querySnapshot =
          await _firestore.collection('Users').get();
      return querySnapshot.docs;
    } catch (e) {
      rethrow;
    }
  }
}
