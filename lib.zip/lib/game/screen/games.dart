import 'package:emergence/selection_provider.dart';
import 'package:flutter/material.dart';
import 'package:emergence/game/games_controller.dart';
import 'package:emergence/users/user_provider.dart';
import 'package:provider/provider.dart';

class GamesScreen extends StatelessWidget {
  const GamesScreen({Key? key});

  @override
  Widget build(BuildContext context) {
    final GamesController gamesController = GamesController();
    final userProvider = Provider.of<UserProvider>(context);
    final String userId = userProvider.userData['userId'];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Games'),
      ),
      body: FutureBuilder<List<Map<String, dynamic>>>(
        future: gamesController.fetchUserGames(userId).then((snapshots) {
          return snapshots;
        }),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          } else if (snapshot.hasError) {
            return Center(child: Text('Error: ${snapshot.error}'));
          } else {
            final List<Map<String, dynamic>> games = snapshot.data ?? [];
            return ListView.builder(
              itemCount: games.length,
              itemBuilder: (context, index) {
                return ListTile(
                  title: ElevatedButton(
                    onPressed: () async {
                      final selectedGame = games[index];
                      final progressionProvider =
                          Provider.of<SelectionProvider>(context,
                              listen: false);
                      progressionProvider.setSelectedGame(selectedGame);
                      Navigator.pushNamed(context, '/units');
                    },
                    child: Text(games[index]["name"]),
                  ),
                );
              },
            );
          }
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, '/add_game');
        },
        tooltip: 'Add Game',
        child: const Icon(Icons.add),
      ),
    );
  }
}
