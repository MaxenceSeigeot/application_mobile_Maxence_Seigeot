import 'package:cloud_firestore/cloud_firestore.dart';

class GamesController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<Map<String, dynamic>>> fetchUserGames(String userId) async {
    try {
      final QuerySnapshot<Map<String, dynamic>> querySnapshot = await _firestore
          .collection('Games')
          .where('players', arrayContains: userId)
          .get();

      final List<Map<String, dynamic>> gamesData =
          querySnapshot.docs.map((doc) {
        return {
          'id': doc.id,
          ...doc.data(),
        };
      }).toList();

      return gamesData;
    } catch (e) {
      rethrow;
    }
  }

  Future<void> deleteGame(String gameId) async {
    try {
      await _firestore.collection('Games').doc(gameId).delete();
    } catch (e) {
      rethrow;
    }
  }

  Future<void> createGame(String name, List<String> players) async {
    try {
      await _firestore.collection('Games').add({
        'name': name,
        'players': players,
      });
    } catch (e) {
      rethrow;
    }
  }
}
