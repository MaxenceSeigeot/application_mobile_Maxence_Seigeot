import 'package:flutter/material.dart';
import 'package:emergence/controllers/auth_controller.dart';
import 'package:emergence/users/user_provider.dart';
import 'package:provider/provider.dart';

void loginService(BuildContext context, TextEditingController emailController,
    TextEditingController passwordController) async {
  AuthController authController = AuthController();

  String email = emailController.text.trim();
  String password = passwordController.text.trim();

  if (email.isNotEmpty && password.isNotEmpty) {
    try {
      var userData = await authController.signIn(email, password);
      if (userData != null) {
        final userProvider = Provider.of<UserProvider>(context, listen: false);
        Map<String, dynamic> userDataMap = {'userId': userData.uid};
        userProvider.setUserData(userDataMap);
        Navigator.pushNamed(context, '/games');
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Connexion impossible, veuillez réessayer.'),
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Une erreur est survenue, veuillez réessayer.'),
        ),
      );
    }
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Veuillez remplir tous les champs.')),
    );
  }
}
