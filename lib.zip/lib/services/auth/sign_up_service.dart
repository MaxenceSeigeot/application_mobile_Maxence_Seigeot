import 'package:flutter/material.dart';
import 'package:emergence/controllers/auth_controller.dart';
import 'package:emergence/users/user_provider.dart';
import 'package:provider/provider.dart';

void signUpService(BuildContext context, TextEditingController emailController,
    TextEditingController passwordController) async {
  AuthController authController = AuthController();

  String email = emailController.text.trim();
  String password = passwordController.text.trim();

  if (email.isNotEmpty && password.isNotEmpty) {
    var userData = await authController.signUp(email, password);
    if (userData != null) {
      final userProvider = Provider.of<UserProvider>(context, listen: false);
      Map<String, dynamic> userData = {
        'email': email,
      };
      userProvider.setUserData(userData);
      Navigator.pushNamed(context, '/games');
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sign up failed. Please try again.')),
      );
    }
  } else {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Please fill all fields.')),
    );
  }
}
