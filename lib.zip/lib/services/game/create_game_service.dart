import 'package:cloud_firestore/cloud_firestore.dart';

final CollectionReference _gamesCollection =
    FirebaseFirestore.instance.collection('Games');
Future<void> createGame(String name, List<String> userIds) async {
  try {
    await _gamesCollection.add({
      'name': name,
      'players': userIds,
    });
  } catch (e) {
    throw Exception('Error creating game: $e');
  }
}
