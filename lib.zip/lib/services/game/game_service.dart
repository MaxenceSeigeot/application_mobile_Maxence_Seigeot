/* import 'create_game_service.dart';
import 'read_game_service.dart';
import 'update_game_service.dart';
import 'delete_game_service.dart';

class GameService {
  final CreateGameService _createGameService = CreateGameService(); */
/*   final ReadGameService _readGameService = ReadGameService();
  final UpdateGameService _updateGameService = UpdateGameService();
  final DeleteGameService _deleteGameService = DeleteGameService(); */

/*   Future<void> createGame(String name) async {
    await createGame(name);
  }
 */
/*   Future<Game> readGame(String gameId) async {
    return await _readGameService.read(gameId);
  }

  Future<void> updateGame(Game game) async {
    await _updateGameService.update(game);
  }

  Future<void> deleteGame(String gameId) async {
    await _deleteGameService.delete(gameId);
  } */
/* } */
