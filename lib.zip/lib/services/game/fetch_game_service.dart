import 'package:cloud_firestore/cloud_firestore.dart';

class FetchUserGamesService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Future<List<String>> fetchUserGames(String userId) async {
    try {
      final querySnapshot = await _firestore
          .collection('Games')
          .where('players', arrayContains: userId)
          .get();
      return querySnapshot.docs.map((doc) => doc['name'] as String).toList();
    } catch (e) {
      rethrow;
    }
  }
}
