import 'package:emergence/group/screen/components/update_group_modal.dart';
import 'package:emergence/models/unit_model.dart';
import 'package:emergence/unit/screen/unit_modal.dart/unit_modal_modal.dart';
import 'package:flutter/material.dart';
import 'package:emergence/models/group_model.dart';
import 'package:emergence/group/service/group_service.dart';
import 'package:emergence/group/screen/components/delete_group_modal.dart';

class GroupContentColumn extends StatelessWidget {
  final List<Group> groups;
  final PageController pageController;
  final int currentIndex;
  final BuildContext context;
  final GroupService groupService; // Add GroupService field

  const GroupContentColumn({
    required this.groups,
    required this.pageController,
    required this.currentIndex,
    required this.context,
    required this.groupService, // Initialize GroupService
    Key? key, // Use Key key instead of super.key
  }) : super(key: key); // No need for super here

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          child: PageView.builder(
            controller: pageController,
            itemCount: groups.length,
            onPageChanged: (index) {
              // Assuming we need to update the state of the parent screen
              // We can pass this callback as a parameter to handle state changes in the parent
              // setState(() {
              //   currentIndex = index;
              // });
            },
            itemBuilder: (context, index) {
              final group = groups[index];
              return _buildGroupWidget(group);
            },
          ),
        ),
        _buildIndicatorBar(groups.length),
      ],
    );
  }

  Widget _buildGroupWidget(Group group) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ListTile(
          title: Text(
            group.name,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          trailing: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              IconButton(
                icon: const Icon(Icons.edit),
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => UpdateGroupModal(
                      groupId: group.id,
                    ),
                  );
                },
              ),
              IconButton(
                icon: const Icon(Icons.delete),
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => DeleteGroupModal(
                      groupId: group.id,
                      groupName: group.name,
                    ),
                  );
                },
              ),
              IconButton(
                icon: const Icon(Icons.add),
                onPressed: () {
                  showDialog(
                    context: context,
                    builder: (context) => UnitModal(unit: newUnit),
                  );
                },
              ),
            ],
          ),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: group.units.map((unit) {
            return Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: ElevatedButton(
                onPressed: () {
                  // Handle unit tap
                },
                child: Text(unit.name),
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 10),
      ],
    );
  }

  Widget _buildIndicatorBar(int pageCount) {
    return SizedBox(
      height: 40,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: pageCount,
        itemBuilder: (context, index) {
          return Container(
            width: 10,
            height: 10,
            margin: const EdgeInsets.symmetric(horizontal: 5),
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: currentIndex == index ? Colors.blue : Colors.grey,
            ),
          );
        },
      ),
    );
  }
}
